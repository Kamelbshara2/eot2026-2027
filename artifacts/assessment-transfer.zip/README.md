# Assessment transfer package

SQLite: assessment-bank.sqlite. Equivalent SQL dump and JSON are included. Assets use relative paths with SHA-256 hashes in assets-manifest.json. IDs and LO links are stable. Grade and track are in classrooms; each question belongs to one scoped LO. `source_kind` distinguishes textbook exercises, concept applications and example variants. FRQ keys are multipart rubrics. Calculator diagrams belong to solutions, not given information.

Import SQLite directly, or `sqlite3 imported.sqlite < assessment-bank.sql`. JSON is suitable for other database engines; the SQL dump uses SQLite syntax. Preserve media paths or remap them during upload. Validate foreign keys and hashes after transfer.

For a real exam, keep this package and answer_keys private. Serve student_questions and options during the attempt; grade on the server and release solutions only when permitted. The website's existing hour-long mock is local practice.

Example: one MCQ from each of the 20 MCQ LOs for 9G3:

```sql
WITH pool AS (
 SELECT q.*, ROW_NUMBER() OVER (PARTITION BY q.learning_outcome_id ORDER BY RANDOM()) AS pick
 FROM questions q JOIN learning_outcomes lo ON lo.id=q.learning_outcome_id
 WHERE lo.classroom_id='9G3' AND q.type='mcq'
)
SELECT id,learning_outcome_id,stem,math_latex FROM pool WHERE pick=1;
```

Retrieve option IDs/text separately and shuffle display order while retaining their canonical IDs. Check that exactly 20 different LOs were selected. Timer, attempts and LMS submission are application responsibilities; this package contains question data, not student records.
