9G3 WEEK 10 — 20-MINUTE SCORM 1.2 EXAM

Import this ZIP as a NEW LMS activity, named "9G3 Week 10 — 20-minute exam". Do not replace an old activity or delete its grades. This package uses a separate identifier and browser attempt key.
Set maximum attempts to ONE and gradebook maximum to TEN. The package reports 0–100, scaled by the LMS to 0–10.

SPECIFICATION
20 minutes from Start, including time away; automatic timeout submission; one attempt; 10 marks.
Three pooled MCQs x 2 marks + one common four-part numeric FRQ x 1 mark per blank.
Random selection of one MCQ per fixed topic pool, shuffled MCQ display order, and shuffled answer choices. The common FRQ remains last. Preserve the exact drawn form, options, responses and original 20-minute deadline on resume.
Required student name and student number; leading zeros and Arabic digits supported.
Embedded diagrams for the dilation-description questions, four graph options in each graph-choice item, and given-term illustrations for every sequence argument and the common FRQ. The illustrations reproduce given terms only and reveal no differences/formulas/future terms.
The description and graph slots never repeat the same textbook exercise. All pool IDs, prompts, choices and keys come from existing Grade 9 Week 10 practice. Every original outcome and topic weight is preserved.

AUDIBLE WARNING
Start or Test / enable alarm unlocks the offline warning tone. Leaving/hiding the exam tab or browser focus starts the tone and logs a warning; returning or submitting stops it. After reopening, use Test / enable alarm again if necessary. Keep device audio on and allow audio in the LMS iframe. Browser/OS restrictions or mute can suppress sound; visible warnings and LMS focus logs remain. Browsers cannot identify which other app was opened. Warnings do not deduct marks.

LMS RECORDS
Submission reports score, completion, chosen MCQ responses, per-blank short answers, student number, focus warnings and displayed question order. Confirmed LMS saving is distinguished from failure; retry saving is available. Test in your actual LMS with a learner before assigning. Hide answer review and allow resuming the same attempt. Do not set a shorter activity timer.

SAFETY
Full-screen request, focus/full-screen-exit recording, copy/paste/context-menu/print restrictions, duplicate-window lock where supported, persisted attempts and completed-attempt locks. These deter casual cheating; they are not secure remote proctoring. No camera/microphone or external tracking. All fonts, diagrams and code are bundled.

SHORT ANSWERS
Each blank earns one independently; no penalty or error-carried-forward credit. Accept equivalent signed numbers, decimals and ordinary fractions, Arabic/Persian digits and Unicode minus within 1e-9 relative tolerance. No algebraic expression or units are required. Students see total only, never the answer key.

Rebuild: node scripts/build-grade9-week10-20min-scorm.mjs. The original 15-minute Grade 9 package and all existing submissions remain untouched.
