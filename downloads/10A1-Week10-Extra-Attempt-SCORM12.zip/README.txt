10A1 WEEK 10 — SEPARATE ADDITIONAL ATTEMPT

Import this ZIP as a NEW SCORM 1.2 activity. DO NOT replace/update the original activity or delete its attempts.
Name the new activity "10A1 Week 10 — Additional attempt".
Set maximum attempts to ONE and maximum grade to TEN. Permit resuming the same new attempt.
Assign/restrict this new activity to the students who submitted the first exam, using your LMS group or access restrictions. The package cannot inspect another LMS activity's completion or grant access by itself.
The original exam's submissions, scores and completion locks stay in the original LMS activity. This new activity records its own score and responses separately. Its package identifier and browser attempt-storage key are different, so the old browser completion does not lock this new exam.
One extra attempt is available through this activity; it is not unlimited retries. Do not merge or overwrite old grades automatically.

ارفع الملف كنشاط SCORM جديد، ولا تستبدل نشاط الاختبار الأول ولا تحذف تسليماته. اضبط المحاولات على 1 والدرجة على 10، وخصص النشاط للطلاب الذين سلموا الاختبار الأول عبر مجموعات أو شروط الإتاحة في نظام LMS.

SAME EXAM SPECIFICATION
15 minutes from Start; 10 marks; three MCQs x 2 and one four-part numeric FRQ x 1 per blank; automated marking; images for every question; student name and number; shuffled topic-pool questions, MCQ order and choices; focus warning sound; same-attempt recovery and automatic timeout submission; score and response reporting to the LMS. Random forms may coincide.

Original package setup and integrity details:
10A1 / Mathematics / Week 10 / SCORM 1.2
15 minutes; one graded attempt; 10 marks.
3 MCQs x 2 marks, one common multipart FRQ with 4 numeric blanks x 1 mark.

LMS SETUP REQUIRED
Import this ZIP directly as SCORM 1.2. Set maximum attempts to ONE, disable restart/new attempts, and set the gradebook maximum to 10. Raw score is normalized to 0–100; LMS scales it to 0–10. No pass threshold is assumed; successful submission reports completed. Permit resuming the SAME attempt. The 15-minute deadline starts after student details and Start, includes time away, and does not reset on refresh. Do not impose a shorter activity timer. Hide answer review until the exam period closes. Test with a learner account in your own LMS before assigning.

IDENTITY
LMS learner ID is authoritative. Required student name and student number are frozen at Start; student number supports leading zeros and Arabic digits. Identity is retained in suspend_data and cmi.comments, and student number is reported as a fill-in interaction. It is not independently verified. No external collection service is used.

FAIRNESS
Exactly one MCQ is drawn from each of the three topic/task pools. Every student receives the same topic weights and task types. For 10A1, the three MCQs are also displayed in a randomly shuffled order, with the common multipart FRQ last. The selected questions, their display order, options, answers and original 15-minute deadline are saved and reused on resume. Previously started attempts retain their original order. Options are shuffled independently; graph options retain their canonical correct-answer mapping. 9G3 never repeats the same source exercise across the description and graph slots. The single FRQ is common to all students in the classroom with identical four-part marking. Pools are reviewed by task type; no statistical/psychometric equivalence claim is made. Random selection can coincide between learners.
- Geometric mean: 5 variants; 2 marks; Find the positive geometric mean of two positive integers in exact radical form.
- Pythagorean theorem: missing leg: 5 variants; 2 marks; Find one missing leg of a right triangle with integer Pythagorean-triple side lengths.
- Special right triangles: 6 variants; 2 marks; Use the 30–60–90 ratio to find two exact side lengths from one labelled side.
FRQ practice sources: 10a1-w10-coordinate-q19. All exam content is adapted from existing Week 10 practice; no unseen exercise is introduced. Every classroom learning outcome is represented.

SHORT ANSWER MARKING
Each blank earns 1 independently; there is no penalty and no automatic error-carried-forward credit. Only numbers are requested. Signed integers, decimals, ordinary fractions, Arabic/Persian digits, Arabic decimal marks, and Unicode minus are supported. Equivalent numeric answers are accepted within 1e-9 relative tolerance. No algebra expressions, units, radicals, or arbitrary executable expressions are accepted; none are required by these FRQs. Students see total only, never the answer key. Interactions report each MCQ and blank separately to the LMS.

INTEGRITY
Full-screen request; focus/tab/full-screen-exit events recorded; copy/paste/context menu/printing restrictions; automatic timed submission; same-attempt recovery; completion lock; same-browser duplicate-window lock where supported. Focus warnings do not deduct marks or automatically disqualify. This is a client-side SCORM exam, not secure proctoring: another device, developer tools, clock manipulation across sessions, clearing browser storage, or an LMS-authorized restart cannot be fully prevented by the ZIP. Use LMS identity/attempt controls and invigilation or a secure browser for high-stakes use. No camera/microphone.

10A1 AUDIBLE WARNING
An offline-generated warning tone loops while the exam is hidden or loses focus and stops on return/submission. Start or Test/enable alarm unlocks audio; after a reload use Test/enable alarm again. Browser focus loss covers tab switches, minimizing, and switching apps; the browser cannot identify the other application. Keep device audio on. Browser/OS autoplay, background policies, iframe permissions, or device mute can suppress sound; the visible warning and LMS focus log remain. This is a warning, not proof of cheating. All 10A1 MCQ pool variants and the multipart FRQ include embedded SVG diagrams.

OFFLINE ASSETS
All math fonts, graphs, CSS and code are bundled. Launch through an LMS; opening index.html directly will not create a graded attempt. Source and reproducible builder: scorm/week10/ and scripts/build-week10-scorm.mjs in the repository.
