10G3 / Mathematics / Week 10 / SCORM 1.2
15 minutes; one graded attempt; 10 marks.
3 MCQs x 2 marks, one common multipart FRQ with 4 numeric blanks x 1 mark.

LMS SETUP REQUIRED
Import this ZIP directly as SCORM 1.2. Set maximum attempts to ONE, disable restart/new attempts, and set the gradebook maximum to 10. Raw score is normalized to 0–100; LMS scales it to 0–10. No pass threshold is assumed; successful submission reports completed. Permit resuming the SAME attempt. The 15-minute deadline starts after student details and Start, includes time away, and does not reset on refresh. Do not impose a shorter activity timer. Hide answer review until the exam period closes. Test with a learner account in your own LMS before assigning.

IDENTITY
LMS learner ID is authoritative. Required student name and student number are frozen at Start; student number supports leading zeros and Arabic digits. Identity is retained in suspend_data and cmi.comments, and student number is reported as a fill-in interaction. It is not independently verified. No external collection service is used.

FAIRNESS
Exactly one MCQ is drawn from each of the three topic/task pools. Every student receives the same topic weights and task types. Options are shuffled independently; graph options retain their canonical correct-answer mapping. 9G3 never repeats the same source exercise across the description and graph slots. The single FRQ is common to all students in the classroom with identical four-part marking. Pools are reviewed by task type; no statistical/psychometric equivalence claim is made. Random selection can coincide between learners.
- Power of a monomial quotient: 3 variants; 2 marks; Apply an outer integer power to a quotient; multiply variable exponents and raise the coefficient.
- Negative and zero exponent outcome: positive-power rewriting: 2 variants; 2 marks; Rewrite a monomial quotient with negative powers using positive exponents.
- Evaluate a rational exponent or root: 7 variants; 2 marks; Evaluate a single exact positive root of a perfect power (possibly a reciprocal).
FRQ practice sources: 10g3-w10-supplied-q28. All exam content is adapted from existing Week 10 practice; no unseen exercise is introduced. Every classroom learning outcome is represented.

SHORT ANSWER MARKING
Each blank earns 1 independently; there is no penalty and no automatic error-carried-forward credit. Only numbers are requested. Signed integers, decimals, ordinary fractions, Arabic/Persian digits, Arabic decimal marks, and Unicode minus are supported. Equivalent numeric answers are accepted within 1e-9 relative tolerance. No algebra expressions, units, radicals, or arbitrary executable expressions are accepted; none are required by these FRQs. Students see total only, never the answer key. Interactions report each MCQ and blank separately to the LMS.

INTEGRITY
Full-screen request; focus/tab/full-screen-exit events recorded; copy/paste/context menu/printing restrictions; automatic timed submission; same-attempt recovery; completion lock; same-browser duplicate-window lock where supported. Focus warnings do not deduct marks or automatically disqualify. This is a client-side SCORM exam, not secure proctoring: another device, developer tools, clock manipulation across sessions, clearing browser storage, or an LMS-authorized restart cannot be fully prevented by the ZIP. Use LMS identity/attempt controls and invigilation or a secure browser for high-stakes use. No camera/microphone.

OFFLINE ASSETS
All math fonts, graphs, CSS and code are bundled. Launch through an LMS; opening index.html directly will not create a graded attempt. Source and reproducible builder: scorm/week10/ and scripts/build-week10-scorm.mjs in the repository.
