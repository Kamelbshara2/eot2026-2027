10G3 / Khalid bin Alwaleed School / Math Week 9
SCORM 1.2: 5 MCQs, 2 marks each, total 10; 10 minutes; one graded attempt.

LMS setup (required):
1. Import the ZIP as SCORM 1.2; launch index.html through the LMS player.
2. Set maximum attempts to ONE. Disable new-attempt/restart and guest access. SCORM 1.2 has no portable manifest setting for an attempt limit.
3. Set the SCORM activity/gradebook maximum to 10. The SCO reports a normalized raw score from 0 to 100 (20 per correct answer); the LMS scales this to 0 to 10 (2 marks per correct answer). Interaction weights are 2; do not add them to the total score again. The student result and teacher comments also record actual marks out of 10. No pass threshold is prescribed; completion is recorded as completed.
4. The SCO enforces 10 minutes from Start. Avoid an additional shorter LMS launch timer (which may include the instructions screen). Permit resuming the same attempt. Reopening does not reset the original deadline. Deadline includes time away from the exam.
5. Keep answer review hidden until your examination period closes. Students see only their total score.
6. Test in your LMS with a learner account before assigning it.

Controls: per-learner question/option shuffle; LMS suspend_data plus browser recovery; automatic timeout submission; completed-attempt lock; full-screen request; focus/full-screen-exit warnings stored in suspend_data and cmi.comments; copy/paste/context menu/print restrictions. Warnings do not automatically deduct marks or disqualify a student.

Limits: browser controls deter casual copying but cannot prevent another device, developer tools, clock tampering across sessions, or a new attempt authorized by the LMS. Client-side SCORM scoring is not secure remote proctoring. Use an LMS secure browser/proctoring service if stronger exam security is required. No camera, microphone or external tracking services are used.

The five questions are the same as the previous 10G3 Week 9 paper exam and already exist in student practice. No new practice items were needed. There is no watermark. All assets and mathematical fonts are included; no network/CDN dependency.
